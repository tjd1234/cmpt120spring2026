# hq2.py

# \    /
#  \  /
#   \/
#   /\
#  /  \
# /    \

print('Question 2')
print('\\    /')
print(' \\  /')
print('  \\/')
print('  /\\')
print(' /  \\')
print('/    \\')

print()
print('\\    /\n \\  /\n  \\/\n  /\\\n /  \\\n/    \\')

print()
print(r"""\\    /
 \\  /
  \\/
  /\\
 /  \\
/    \\""")