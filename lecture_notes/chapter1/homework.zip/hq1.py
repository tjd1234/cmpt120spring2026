# hq1.py

#
# Print this:
# \n \t \\ \' \" are escape characters
#

print('Question 1')
print('\\n \\t \\\\ \\\' \\\" are escape characters')
print("\\n \\t \\\\ \\\' \\\" are escape characters")
print("""\\n \\t \\\\ \\' \\" are escape characters""")